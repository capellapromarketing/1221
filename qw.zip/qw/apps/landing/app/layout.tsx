import '@/styles/globals.css';
import type { Metadata } from 'next';
import { Toaster } from "@/ui/toaster";
import { TooltipProvider } from "@/ui/tooltip";

export const metadata: Metadata = {
  title: 'Capella Pro - AI Powered Productivity OS',
  description: 'Transform your workflow with Capella Pro - the AI-powered productivity operating system where your work evolves into an intelligent ecosystem. Get lifetime benefits today.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <TooltipProvider>
          {children}
          <Toaster />
        </TooltipProvider>
      </body>
    </html>
  );
}
