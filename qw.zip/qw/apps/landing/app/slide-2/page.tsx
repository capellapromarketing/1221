"use client";
import React from "react";
import { 
  LayoutDashboard, 
  CheckSquare, 
  Calendar, 
  DollarSign, 
  Users, 
  FileText, 
  LayoutTemplate, 
  PenTool,
  Sparkles
} from "lucide-react";

const features = [
  { name: "Dashboard", icon: LayoutDashboard, description: "Overview & insights" },
  { name: "Tasks", icon: CheckSquare, description: "Track & complete" },
  { name: "Calendar", icon: Calendar, description: "Schedule & plan" },
  { name: "Finance", icon: DollarSign, description: "Invoices & payments" },
  { name: "Clients", icon: Users, description: "CRM & contacts" },
  { name: "Notes", icon: FileText, description: "Ideas & documents" },
  { name: "Templates", icon: LayoutTemplate, description: "Ready-made workflows" },
  { name: "Whiteboard", icon: PenTool, description: "Visual collaboration" },
  { name: "AI Tools", icon: Sparkles, description: "Smart automation" },
];

export default function Slide2Page() {
  return (
    <section className="w-screen min-h-screen bg-white flex flex-col items-center justify-center py-16 px-8">
      <div className="text-center mb-12">
        <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-4 tracking-tight">
          Your Business at a Glance
        </h1>
        <p className="text-xl text-gray-500 max-w-2xl mx-auto">
          Capella Pro Dashboard — All your tools in one place
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl w-full">
        {features.map((feature, index) => {
          const Icon = feature.icon;
          return (
            <button
              key={feature.name}
              className="group relative bg-white border border-gray-200 rounded-2xl p-6 text-left transition-all duration-300 ease-out hover:scale-[1.02] hover:shadow-xl hover:shadow-cyan-500/10 hover:border-cyan-400/50 focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:ring-offset-2"
              style={{
                animation: `fadeSlideUp 0.5s ease-out ${index * 0.08}s both`,
              }}
            >
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-cyan-50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              
              <div className="relative z-10">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-400 to-teal-500 flex items-center justify-center mb-4 shadow-lg shadow-cyan-500/25 group-hover:shadow-cyan-500/40 transition-shadow duration-300">
                  <Icon className="w-6 h-6 text-white" strokeWidth={2} />
                </div>
                
                <h3 className="text-lg font-semibold text-gray-900 mb-1 group-hover:text-cyan-700 transition-colors duration-300">
                  {feature.name}
                </h3>
                
                <p className="text-sm text-gray-500 group-hover:text-gray-600 transition-colors duration-300">
                  {feature.description}
                </p>
              </div>

              <div className="absolute top-4 right-4 w-2 h-2 rounded-full bg-cyan-400 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </button>
          );
        })}
      </div>

      <style jsx>{`
        @keyframes fadeSlideUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </section>
  );
}
