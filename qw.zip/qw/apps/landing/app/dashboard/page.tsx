"use client";
import React from "react";

export default function DashboardPage() {
  return (
    <section className="w-screen h-screen bg-black text-white flex flex-col items-center justify-center">
      <h1 className="text-5xl font-bold text-emerald-400 mb-6 drop-shadow-[0_0_14px_rgba(0,255,200,0.6)]">
        DASHBOARD
      </h1>
      <p className="text-xl text-white/80 max-w-2xl text-center">
        Your unified command center for productivity. Manage tasks, calendar, finances, and more from one intelligent interface.
      </p>
    </section>
  );
}
