"use client";
import React from "react";
import Footer from "@/components/Footer";

export default function Slide4Page() {
  return (
    <footer className="w-screen h-screen flex items-end bg-black">
      <div className="w-full">
        <Footer />
      </div>
    </footer>
  );
}
