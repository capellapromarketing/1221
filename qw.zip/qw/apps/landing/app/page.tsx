import Navbar from '@/components/Navbar';
import HeroSection from '@/components/HeroSection';
import Testimonials from '@/components/Testimonials';
import Footer from '@/components/Footer';

/**
 * Landing Page
 * 
 * The main entry point for the application.
 * Displays the landing page sections: Navbar, Hero, Testimonials, Footer.
 */
export default function Page() {
  return (
    <main className="min-h-screen bg-black overflow-x-hidden w-full">
      <Navbar />
      <HeroSection />
      <Testimonials />
      <Footer />
    </main>
  );
}
