"use client";
import React from "react";
import ComponentsSlide from "@/components/Slides/ComponentsSlide";

export default function Slide1Page() {
  return (
    <main className="w-screen h-screen bg-black">
      <ComponentsSlide />
    </main>
  );
}
