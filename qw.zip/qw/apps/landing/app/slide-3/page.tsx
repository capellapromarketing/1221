"use client";
import React from "react";
import Testimonials from "@/components/Testimonials";

export default function Slide3Page() {
  return (
    <section className="w-screen min-h-screen bg-black flex items-center justify-center">
      <div className="w-full">
        <Testimonials />
      </div>
    </section>
  );
}
