"use client";

import { useEffect, useState } from 'react';

const testimonials = [
  {
    id: 1,
    quote: "Finally, a productivity system that doesn't require managing 10 different tools just to stay organized.\n\nI genuinely feel lighter switching everything into one platform."
  },
  {
    id: 2,
    quote: "Five disconnected tools killed efficiency in my previous workflow.\n\nA unified system is the future, and Capella Pro feels like the first solution that actually understands that."
  },
  {
    id: 3,
    quote: "This is actually a game-changer for productivity.\n\nI haven't seen something this structured yet so easy to use.\n\nExcited to see how Capella evolves!"
  },
  {
    id: 4,
    quote: "AI-based productivity engine is interesting.\n\nIf this evolves even a little more, it will remove half the manual management I currently do daily."
  },
  {
    id: 5,
    quote: "I used to spend more money purchasing separate tools than actually working.\n\nFinally, productivity that doesn't require selling a kidney."
  },
  {
    id: 6,
    quote: "I've tried to build workflows many times and always dropped because of system complexity.\n\nCapella actually removes the barrier and lets you start instantly."
  },
  {
    id: 7,
    quote: "The idea of having tasks, notes, a calendar, and payments in one single interface is insane.\n\nNo switching between tabs.\n\nThat's how productivity tools should work."
  },
  {
    id: 8,
    quote: "Love that Capella Pro actually feels like an OS.\n\nSidebar navigation, unified workspace, connected data.\n\nSuper clean approach. This is what modern workspaces were missing."
  },
  {
    id: 9,
    quote: "AI suggestions on top of tasks and calendar is a game-changer.\n\nNot just storing data, actually guiding decisions.\n\nThis could simplify everyday planning massively."
  }
];

export default function Testimonials() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section 
      id="testimonials"
      className="w-full flex flex-col items-center justify-center bg-black text-white py-24"
      data-testid="testimonials-section"
    >
      <div className="max-w-6xl mx-auto px-4 w-full">
        <h2 
          className="text-center text-5xl font-bold text-emerald-300 drop-shadow-[0_0_14px_rgba(0,255,200,0.6)] whitespace-nowrap mx-auto mt-10 mb-12 w-full flex justify-center"
          data-testid="text-testimonials-heading"
        >
          SUCCESS STORIES FUELING OUR MISSION
        </h2>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((testimonial, index) => (
            <article
              key={testimonial.id}
              className={`
                h-full rounded-3xl
                border border-emerald-500/20
                bg-gradient-to-b from-emerald-500/5 to-transparent
                p-8
                flex flex-col
                hover:border-emerald-400/40
                hover:-translate-y-1
                transition-all duration-300 ease-out
                ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}
              `}
              style={{ 
                transitionDelay: `${index * 80}ms`
              }}
              data-testid={`card-testimonial-${testimonial.id}`}
            >
              <p 
                className="text-sm md:text-base leading-relaxed text-neutral-300 font-light whitespace-pre-line"
                data-testid={`text-testimonial-quote-${testimonial.id}`}
              >
                {testimonial.quote}
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
