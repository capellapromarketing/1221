"use client";

import { useState, useEffect, useCallback } from 'react';
import { Menu, X } from 'lucide-react';
import Link from 'next/link';

const menuItems = [
  { title: 'Features', href: '#features' },
  { title: 'Privacy Policy', href: '/privacy' },
  { title: 'Terms of Service', href: '/terms' },
];

const secondaryLinks = [
  { title: 'Refund Policy', href: '/refund' },
  { title: 'Contact / Support', href: 'mailto:capellapro.co@gmail.com' },
];

export default function Navbar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isPanelOpen, setIsPanelOpen] = useState(false);

  const closePanel = useCallback(() => {
    setIsPanelOpen(false);
  }, []);

  const closeMobileMenu = useCallback(() => {
    setIsMobileMenuOpen(false);
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        closePanel();
        closeMobileMenu();
      }
    };

    if (isPanelOpen || isMobileMenuOpen) {
      document.addEventListener('keydown', handleKeyDown);
    }

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isPanelOpen, isMobileMenuOpen, closePanel, closeMobileMenu]);

  const handleSmoothScroll = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    if (href.startsWith('#')) {
      e.preventDefault();
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
      closeMobileMenu();
      closePanel();
    }
  };

  return (
    <>
      <nav 
        className="absolute top-0 left-0 right-0 z-50 bg-black border-b border-white/10" 
        data-testid="navbar"
      >
        <div className="w-full px-3 md:px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex-shrink-0">
              <Link href="/" className="flex items-center" data-testid="link-logo">
                <span className="text-xl md:text-2xl font-semibold tracking-tight text-emerald-400">CAPELLA PRO</span>
              </Link>
            </div>

            <div className="hidden md:flex items-center gap-6 lg:gap-8">
              {menuItems.map((item) => (
                <Link
                  key={item.title}
                  href={item.href}
                  onClick={(e) => handleSmoothScroll(e as any, item.href)}
                  className="text-sm md:text-base font-medium text-neutral-200 py-2 hover:text-emerald-400 transition-colors"
                  data-testid={`link-nav-${item.title.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  {item.title}
                </Link>
              ))}
              
              <button
                onClick={() => setIsPanelOpen(!isPanelOpen)}
                className="p-2 bg-transparent border-none shadow-none hover:bg-white/10 rounded-full transition-colors"
                aria-label="Open menu panel"
                data-testid="button-hamburger"
              >
                <Menu className="h-5 w-5 text-neutral-200" />
              </button>
            </div>

            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 bg-transparent border-none shadow-none hover:bg-white/10 rounded-full transition-colors"
              data-testid="button-mobile-menu"
            >
              {isMobileMenuOpen ? <X className="h-5 w-5 text-neutral-200" /> : <Menu className="h-5 w-5 text-neutral-200" />}
            </button>
          </div>
        </div>

        {isMobileMenuOpen && (
          <div className="md:hidden bg-neutral-900/95 backdrop-blur-md border-t border-white/10" data-testid="mobile-menu">
            <div className="max-w-6xl mx-auto px-6 py-4 space-y-1">
              {menuItems.map((item) => (
                <Link
                  key={item.title}
                  href={item.href}
                  onClick={(e) => handleSmoothScroll(e as any, item.href)}
                  className="block px-3 py-2 text-neutral-200 hover:text-emerald-400 font-medium rounded-md transition-colors"
                  data-testid={`link-mobile-${item.title.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  {item.title}
                </Link>
              ))}
              <div className="border-t border-white/10 my-3" />
              {secondaryLinks.map((item) => (
                <Link
                  key={item.title}
                  href={item.href}
                  onClick={(e) => handleSmoothScroll(e as any, item.href)}
                  className="block px-3 py-2 text-neutral-400 hover:text-emerald-400 font-medium rounded-md text-sm transition-colors"
                >
                  {item.title}
                </Link>
              ))}
            </div>
          </div>
        )}
      </nav>

      {isPanelOpen && (
        <>
          <div 
            className="fixed inset-0 z-40 bg-black/30"
            onClick={closePanel}
            data-testid="panel-overlay"
          />
          
          <div 
            className="fixed right-3 top-16 z-50 bg-neutral-800/95 backdrop-blur-md border border-white/15 shadow-lg rounded-lg py-2 px-1"
            data-testid="panel-menu"
          >
            {secondaryLinks.map((item) => (
              <Link
                key={item.title}
                href={item.href}
                onClick={(e) => handleSmoothScroll(e as any, item.href)}
                className="block px-4 py-1.5 text-sm text-neutral-200 hover:text-emerald-400 hover:bg-white/5 rounded transition-colors whitespace-nowrap"
              >
                {item.title}
              </Link>
            ))}
          </div>
        </>
      )}
    </>
  );
}
