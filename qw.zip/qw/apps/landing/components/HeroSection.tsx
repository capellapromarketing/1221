"use client";

import { useState } from 'react';
import '@/styles/hero.css';

const roles = [
  'BUSINESS OWNERS',
  'FREELANCER',
  'SOLOPRENEURS',
  'REMOTE WORKER',
  'STUDENT',
  'OTHER'
];

export default function HeroSection() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    role: ''
  });
  const [errors, setErrors] = useState({ name: '', email: '' });

  const handleOpenModal = () => {
    setIsModalOpen(true);
    setStep(1);
    setFormData({ name: '', email: '', role: '' });
    setErrors({ name: '', email: '' });
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setStep(1);
  };

  const handleBack = () => {
    setStep(1);
  };

  const validateStep1 = () => {
    const newErrors = { name: '', email: '' };
    let isValid = true;

    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
      isValid = false;
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
      isValid = false;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email';
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleContinue = () => {
    if (validateStep1()) {
      setStep(2);
    }
  };

  const handleRoleSelect = (role: string) => {
    setFormData(prev => ({ ...prev, role }));
  };

  const handleSubmit = () => {
    if (formData.role) {
      console.log('Form submitted:', formData);
      handleCloseModal();
    }
  };

  return (
    <section 
      id="hero"
      className="relative w-full min-h-screen bg-black text-white overflow-hidden"
      data-testid="hero-section"
    >
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4 pb-32 pt-16">
        <h1 
          className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-semibold tracking-tight text-[#00E5A0] leading-tight lg:whitespace-nowrap hero-text-glow"
          data-testid="text-headline"
        >
          AI POWERED PRODUCTIVITY OS
        </h1>

        <p 
          className="mt-6 text-base sm:text-lg md:text-xl lg:text-2xl text-neutral-100 lg:whitespace-nowrap hero-text-glow-subtle font-bold text-center"
          data-testid="text-subheading"
        >WHERE YOUR WORK EVOLVES INTO AN INTELLIGENT ECOSYSTEM</p>

        <button
          onClick={handleOpenModal}
          className="mt-8 md:mt-12 px-8 py-4 bg-[#14b8a6] hover:bg-[#0d9488] text-[#0b0b0b] font-semibold text-base md:text-lg tracking-wide rounded-lg shadow-sm hover:shadow-md focus:outline-none focus:ring-2 focus:ring-[#14b8a6]/40 transition-all motion-reduce:transition-none motion-reduce:transform-none"
          data-testid="button-cta"
          aria-label="Get lifetime benefits"
        >
          GET LIFETIME BENEFITS
        </button>

        <p className="mt-6 text-xs md:text-sm text-white/50 tracking-widest uppercase text-center">
          NO CARD REQUIRED / LIMITED EARLY ACCESS
        </p>
      </div>

      {isModalOpen && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center min-h-screen bg-black/70 backdrop-blur-sm"
          onClick={handleCloseModal}
        >
          <div 
            className="relative w-[90%] max-w-md sm:max-w-lg bg-black/40 backdrop-blur-md border border-white/10 rounded-2xl p-6 sm:p-8 shadow-2xl cta-modal-content"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={handleCloseModal}
              className="absolute top-4 right-4 text-white/40 hover:text-white transition-colors focus:outline-none focus:ring-2 focus:ring-[#14b8a6]/40 rounded-md p-1"
              aria-label="Close modal"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>

            {step === 1 && (
              <div className="space-y-6">
                <div className="text-center">
                  <h2 className="text-xl md:text-2xl font-semibold text-white mb-2">Get Early Access</h2>
                  <p className="text-white/50 text-sm">Enter your details to continue</p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label htmlFor="name" className="block text-sm text-white/70 mb-2">Name</label>
                    <input
                      type="text"
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      className={`w-full px-4 py-3 bg-white/5 border ${errors.name ? 'border-red-500' : 'border-white/10'} rounded-lg text-white placeholder-white/30 focus:outline-none focus:border-[#14b8a6] focus:ring-2 focus:ring-[#14b8a6]/30 transition-colors`}
                      placeholder="Enter your name"
                      aria-label="Name"
                    />
                    {errors.name && <p className="mt-1 text-xs text-red-400">{errors.name}</p>}
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm text-white/70 mb-2">Email</label>
                    <input
                      type="email"
                      id="email"
                      value={formData.email}
                      onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                      className={`w-full px-4 py-3 bg-white/5 border ${errors.email ? 'border-red-500' : 'border-white/10'} rounded-lg text-white placeholder-white/30 focus:outline-none focus:border-[#14b8a6] focus:ring-2 focus:ring-[#14b8a6]/30 transition-colors`}
                      placeholder="Enter your email"
                      aria-label="Email"
                    />
                    {errors.email && <p className="mt-1 text-xs text-red-400">{errors.email}</p>}
                  </div>
                </div>

                <button
                  onClick={handleContinue}
                  className="w-full md:w-auto md:mx-auto md:block py-3.5 px-8 bg-[#14b8a6] hover:bg-[#0d9488] text-[#0b0b0b] font-semibold rounded-lg shadow-sm hover:shadow-md focus:outline-none focus:ring-2 focus:ring-[#14b8a6]/40 transition-all motion-reduce:transition-none"
                >
                  Continue
                </button>

                <p className="text-center mt-4 text-xs text-gray-400 tracking-wider uppercase">
                  LIMITED TIME ACCESS
                </p>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <button
                  onClick={handleBack}
                  className="absolute left-4 top-4 p-2 rounded-md text-gray-200 hover:text-white focus:outline-none focus:ring-2 focus:ring-[#14b8a6]/30 transition-colors"
                  aria-label="Back"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </button>

                <div className="text-center">
                  <h2 className="text-xl md:text-2xl font-semibold text-white mb-2">WHAT BEST DESCRIBES YOU</h2>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {roles.map((role) => (
                    <button
                      key={role}
                      onClick={() => handleRoleSelect(role)}
                      className={`px-4 py-3 text-xs md:text-sm font-medium tracking-wide rounded-lg border transition-all motion-reduce:transition-none ${
                        formData.role === role
                          ? 'bg-[#14b8a6]/20 border-[#14b8a6] text-[#14b8a6] shadow-[0_0_15px_rgba(20,184,166,0.3)]'
                          : 'bg-white/5 border-white/10 text-white/70 hover:bg-white/10 hover:border-white/20'
                      } focus:outline-none focus:ring-2 focus:ring-[#14b8a6]/40`}
                    >
                      {role}
                    </button>
                  ))}
                </div>

                <button
                  onClick={handleSubmit}
                  disabled={!formData.role}
                  className={`w-full md:w-auto md:mx-auto md:block py-3.5 px-8 font-semibold rounded-lg shadow-sm transition-all motion-reduce:transition-none ${
                    formData.role
                      ? 'bg-[#14b8a6] hover:bg-[#0d9488] text-[#0b0b0b] hover:shadow-md focus:outline-none focus:ring-2 focus:ring-[#14b8a6]/40'
                      : 'bg-white/10 text-white/30 cursor-not-allowed'
                  }`}
                >
                  Submit
                </button>

                <p className="text-center mt-4 text-xs text-gray-400 tracking-wider uppercase">
                  LIMITED TIME ACCESS
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
