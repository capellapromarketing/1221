import Link from 'next/link';
import { Linkedin, Mail, Instagram } from 'lucide-react';

const XIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" className={className} fill="currentColor">
    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
  </svg>
);

const footerLinks = {
  product: {
    title: 'Product',
    links: [
      { name: 'Features', href: '#features' },
      { name: 'Pricing', href: '#pricing' },
      { name: 'Templates', href: '#templates' }
    ]
  },
  company: {
    title: 'Company',
    links: [
      { name: 'About', href: '#about' },
      { name: 'Community', href: '#community' }
    ]
  },
  support: {
    title: 'Support',
    links: [
      { name: 'Contact', href: '#contact' }
    ]
  },
  legal: {
    title: 'Legal',
    links: [
      { name: 'Privacy Policy', href: '/privacy' },
      { name: 'Terms of Service', href: '/terms' },
      { name: 'Refund Policy', href: '/refund' }
    ]
  }
};

const SocialIcons = () => (
  <div className="flex items-center justify-center gap-8">
    <a 
      href="https://x.com/CAPELLA_HQ"
      target="_blank"
      rel="noreferrer"
      aria-label="X (Twitter)" 
      className="text-white hover:text-emerald-400 hover:scale-110 transition-all duration-300 hover:drop-shadow-[0_0_8px_rgba(16,185,129,0.5)]"
    >
      <XIcon className="h-6 w-6" />
    </a>
    <a 
      href="https://www.linkedin.com/in/capella-pro-31a413377/"
      target="_blank"
      rel="noreferrer"
      aria-label="LinkedIn" 
      className="text-white hover:text-emerald-400 hover:scale-110 transition-all duration-300 hover:drop-shadow-[0_0_8px_rgba(16,185,129,0.5)]"
    >
      <Linkedin className="h-6 w-6" />
    </a>
    <a 
      href="https://instagram.com"
      target="_blank"
      rel="noreferrer"
      aria-label="Instagram" 
      className="text-white hover:text-emerald-400 hover:scale-110 transition-all duration-300 hover:drop-shadow-[0_0_8px_rgba(16,185,129,0.5)]"
    >
      <Instagram className="h-6 w-6" />
    </a>
    <a 
      href="mailto:capellapro.co@gmail.com"
      aria-label="Email" 
      className="text-white hover:text-emerald-400 hover:scale-110 transition-all duration-300 hover:drop-shadow-[0_0_8px_rgba(16,185,129,0.5)]"
    >
      <Mail className="h-6 w-6" />
    </a>
  </div>
);

export default function Footer() {
  return (
    <footer className="w-full bg-black text-neutral-100" data-testid="footer-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 md:pt-16 lg:pt-20 pb-6">
        
        <div className="mb-10 md:mb-14">
          <div className="flex justify-center w-full">
            <div className="inline-block text-center">
              <h2 
                className="text-[clamp(2.5rem,10vw,8rem)] tracking-[-0.03em] text-neutral-50 leading-none whitespace-nowrap font-light"
                data-testid="text-footer-heading"
              >
                Capella Professionals
              </h2>
              <div className="mt-3 md:mt-4 h-[2px] w-full bg-neutral-600" />
            </div>
          </div>
        </div>

        <div className="mb-10 md:mb-14">
          <SocialIcons />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-x-8 gap-y-6 text-sm max-w-4xl mx-auto px-4 mb-8">
          {Object.entries(footerLinks).map(([key, section]) => (
            <div key={key} data-testid={`footer-column-${key}`} className="text-left">
              <h3 className="font-semibold text-neutral-100 mb-2 text-sm">{section.title}</h3>
              <ul className="space-y-1.5">
                {section.links.map((link) => (
                  <li key={link.name} className="leading-relaxed">
                    {link.href.startsWith('/') ? (
                      <Link 
                        href={link.href}
                        className="text-neutral-400 hover:text-emerald-400 transition-colors text-[13px]"
                        data-testid={`link-footer-${link.name.toLowerCase().replace(/\s+/g, '-')}`}
                      >
                        {link.name}
                      </Link>
                    ) : (
                      <a 
                        href={link.href}
                        className="text-neutral-400 hover:text-emerald-400 transition-colors text-[13px]"
                        data-testid={`link-footer-${link.name.toLowerCase().replace(/\s+/g, '-')}`}
                      >
                        {link.name}
                      </a>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-neutral-800/50 pt-4 pb-2 text-[10px] sm:text-xs text-neutral-600 text-center">
          <p data-testid="text-footer-copyright">
            © 2025 Capella Pro. All rights reserved.
          </p>
        </div>

      </div>
    </footer>
  );
}
