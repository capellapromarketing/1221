# Slides Components

This folder contains interactive slide components used by the landing slides.

## Components

- **ComponentsSlide.tsx** - Interactive left-column component buttons for Capella Pro

## Usage

```tsx
import ComponentsSlide from "@/components/Slides/ComponentsSlide";

export default function Page() {
  return <ComponentsSlide />;
}
```

## Route

Available at `/slide-1` via `apps/landing/app/slide-1/page.tsx`.

## Customization

### Premium Text
Edit lines 81-84 in `ComponentsSlide.tsx`:
```tsx
<h3>Premium effect activated</h3>
<p>Nice — experience the boost</p>
```

### Animation Duration
- Premium overlay: Change `1200` in `setTimeout` (line 23)
- Button active state: Change `500` in `setTimeout` (line 24)
- Ripple animation: Modify `600ms` in CSS (line 137)
- Glow animation: Modify `700ms` in CSS (line 141)

### Component List
Edit the `components` array (lines 5-14) to add/remove buttons:
```tsx
const components = [
  "Dashboard",
  "Tasks",
  "Calendar",
  "Finance",
  "Clients",
  "Notes",
  "Templates",
  "Whiteboard",
];
```

## Accessibility

- Full keyboard navigation (Tab, Enter, Space)
- ARIA labels and `aria-pressed` state
- Focus ring indicators
