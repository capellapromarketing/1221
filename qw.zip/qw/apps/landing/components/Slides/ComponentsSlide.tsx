"use client";

import React, { useState } from "react";

const components = [
  "Dashboard",
  "Tasks",
  "Calendar",
  "Finance",
  "Clients",
  "Notes",
  "Templates",
  "Whiteboard",
];

export default function ComponentsSlide() {
  const [active, setActive] = useState<number | null>(null);
  const [showPremium, setShowPremium] = useState(false);

  function handleClick(name: string, idx: number) {
    setActive(idx);
    setShowPremium(true);
    setTimeout(() => setShowPremium(false), 1200);
    setTimeout(() => setActive(null), 500);
  }

  return (
    <section className="w-screen h-screen bg-black text-white relative overflow-hidden">
      <div className="absolute left-8 top-1/2 -translate-y-1/2">
        <nav aria-label="Capella components" className="space-y-4">
          {components.map((name, idx) => {
            const isActive = idx === active;
            return (
              <button
                key={name}
                onClick={() => handleClick(name, idx)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") handleClick(name, idx);
                }}
                aria-pressed={isActive}
                className={
                  "group relative flex items-center w-56 text-left px-5 py-3 rounded-2xl transform transition-all duration-300 focus:outline-none focus:ring-4 focus:ring-opacity-30 " +
                  (isActive
                    ? "scale-110 ring-2 ring-offset-2 ring-white/20 shadow-lg"
                    : "hover:scale-105 hover:translate-x-1")
                }
              >
                <span
                  className={
                    "absolute inset-0 rounded-2xl opacity-0 transition-opacity duration-400 group-hover:opacity-30 " +
                    (isActive ? "opacity-60 animate-glow" : "")
                  }
                  aria-hidden="true"
                  style={{
                    background:
                      "linear-gradient(90deg, rgba(127,255,212,0.08), rgba(127,255,212,0.04))",
                    backdropFilter: "blur(6px)",
                  }}
                />
                <span className="relative z-10 text-base font-semibold text-white/95">
                  {name}
                </span>
                <span
                  className={
                    "absolute right-4 h-3 w-3 rounded-full opacity-0 transform scale-75 transition-all " +
                    (isActive ? "animate-ripple opacity-100" : "")
                  }
                />
              </button>
            );
          })}
        </nav>
      </div>

      {showPremium && (
        <div
          className="absolute inset-0 z-30 flex items-center justify-center pointer-events-none"
          aria-hidden="true"
        >
          <div className="px-6 py-3 rounded-xl bg-white/5 backdrop-blur-md border border-white/10 text-center animate-premium">
            <h3 className="text-2xl font-extrabold tracking-wide text-white">
              Premium effect activated
            </h3>
            <p className="text-sm text-white/70 mt-1">Nice — experience the boost</p>
          </div>
        </div>
      )}

      <div className="absolute left-8 bottom-8 text-xs text-white/50">
        Click any component to preview the premium effect
      </div>

      <style jsx>{`
        @keyframes ripple {
          0% {
            transform: scale(0.6);
            opacity: 0.9;
          }
          60% {
            transform: scale(1.6);
            opacity: 0.35;
          }
          100% {
            transform: scale(2.4);
            opacity: 0;
          }
        }
        @keyframes glow {
          0% {
            filter: drop-shadow(0 0 0 rgba(127, 255, 212, 0.0));
          }
          50% {
            filter: drop-shadow(0 0 12px rgba(127, 255, 212, 0.7));
          }
          100% {
            filter: drop-shadow(0 0 0 rgba(127, 255, 212, 0.0));
          }
        }
        @keyframes premium {
          0% {
            transform: translateY(20px) scale(0.98);
            opacity: 0;
            filter: blur(6px);
          }
          30% {
            transform: translateY(0) scale(1.02);
            opacity: 1;
            filter: blur(0);
          }
          100% {
            transform: translateY(-6px) scale(1);
            opacity: 1;
          }
        }

        .animate-ripple {
          animation: ripple 600ms ease-out forwards;
          background: radial-gradient(circle at center, rgba(127,255,212,0.9), rgba(127,255,212,0.35), rgba(127,255,212,0));
        }
        .animate-glow {
          animation: glow 700ms ease-in-out;
        }
        .animate-premium {
          animation: premium 420ms cubic-bezier(0.2, 1, 0.2, 1);
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.6);
        }
      `}</style>
    </section>
  );
}
