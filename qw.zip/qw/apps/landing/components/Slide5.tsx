export default function Slide5() {
  return (
    <section 
      id="slide5" 
      className="w-full bg-black text-white min-h-screen flex items-start pt-16 md:pt-24 lg:pt-32"
      data-testid="slide5-section"
    >
      <div className="w-full px-4 md:px-8 lg:px-16">
        <div className="w-full">
          <div className="flex justify-center overflow-hidden">
            <h2 
              className="inline-block text-4xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl 2xl:text-9xl tracking-tight font-bold text-white whitespace-nowrap relative"
              data-testid="text-slide5-headline"
            >
              Capella Professionals
              <span className="absolute left-0 right-0 bottom-[0.15em] h-1 bg-white/80"></span>
            </h2>
          </div>
          
          <div className="mt-4 md:mt-6 flex justify-end">
            <p 
              className="text-sm sm:text-base md:text-lg lg:text-xl tracking-[0.15em] uppercase text-white/70"
              data-testid="text-slide5-tagline"
            >
              — BUILT TO DO WHAT YOUR FAVOURITE TOOLS CAN'T
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
