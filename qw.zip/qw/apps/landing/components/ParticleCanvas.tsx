"use client";

import { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  baseX: number;
  baseY: number;
  size: number;
  speed: number;
}

export default function ParticleCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resizeCanvas();

    const particles: Particle[] = [];
    const particleCount = 60;
    const mouse = { x: null as number | null, y: null as number | null, radius: 150 };

    const createParticle = (): Particle => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      baseX: Math.random() * canvas.width,
      baseY: Math.random() * canvas.height,
      size: 2,
      speed: 0.05,
    });

    for (let i = 0; i < particleCount; i++) {
      particles.push(createParticle());
    }

    const drawParticle = (particle: Particle) => {
      ctx.fillStyle = 'rgba(0, 229, 160, 0.4)';
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
      ctx.closePath();
      ctx.fill();
    };

    const updateParticle = (particle: Particle) => {
      if (mouse.x !== null && mouse.y !== null) {
        const dx = mouse.x - particle.x;
        const dy = mouse.y - particle.y;
        const distance = Math.sqrt(dx * dx + dy * dy);

        if (distance < mouse.radius) {
          const angle = Math.atan2(dy, dx);
          const force = (mouse.radius - distance) / mouse.radius;
          const moveX = Math.cos(angle) * force * 3;
          const moveY = Math.sin(angle) * force * 3;
          particle.x += moveX;
          particle.y += moveY;
        } else {
          if (particle.x !== particle.baseX) {
            const dx = particle.x - particle.baseX;
            particle.x -= dx * particle.speed;
          }
          if (particle.y !== particle.baseY) {
            const dy = particle.y - particle.baseY;
            particle.y -= dy * particle.speed;
          }
        }
      } else {
        if (particle.x !== particle.baseX) {
          const dx = particle.x - particle.baseX;
          particle.x -= dx * particle.speed;
        }
        if (particle.y !== particle.baseY) {
          const dy = particle.y - particle.baseY;
          particle.y -= dy * particle.speed;
        }
      }
      drawParticle(particle);
    };

    const handleMouseMove = (e: MouseEvent) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    };

    const handleMouseLeave = () => {
      mouse.x = null;
      mouse.y = null;
    };

    const handleResize = () => {
      resizeCanvas();
      particles.forEach((particle) => {
        particle.baseX = Math.random() * canvas.width;
        particle.baseY = Math.random() * canvas.height;
        particle.x = particle.baseX;
        particle.y = particle.baseY;
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseleave', handleMouseLeave);
    window.addEventListener('resize', handleResize);

    let animationId: number;
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach(updateParticle);
      animationId = requestAnimationFrame(animate);
    };
    animate();

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseleave', handleMouseLeave);
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 pointer-events-none"
      style={{ zIndex: 1 }}
      data-testid="particle-canvas"
    />
  );
}
