# Capella Pro Landing Page

## Overview
This is a Next.js monorepo containing the Capella Pro landing page - an AI-powered productivity OS. The project uses a workspace-based monorepo structure with the main landing application in `apps/landing`.

## Project Structure
```
/
├── apps/
│   └── landing/           # Next.js landing page application
│       ├── app/           # Next.js App Router pages
│       ├── components/    # React components
│       ├── hooks/         # Custom React hooks
│       ├── styles/        # CSS and Tailwind styles
│       ├── ui/            # shadcn/ui component library
│       └── utils/         # Utility functions
├── package.json           # Root monorepo configuration
└── tsconfig.json          # TypeScript configuration
```

## Tech Stack
- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS with shadcn/ui components
- **Animation**: Framer Motion
- **UI Components**: Radix UI primitives

## Development
The development server runs on port 5000 with `npm run dev`.

## Deployment
Configured for autoscale deployment:
- Build: `npm run build`
- Start: `npm run start`

## Recent Changes (Dec 2024)

### Hero CTA & Modal Polish
- **Hero CTA Button**: Updated to rectangular shape with rounded-lg corners, aquamarine (#14b8a6) background, dark text (#0b0b0b), shadow effects, and accessible focus states
- **CTA Modal**: Glassy appearance with `bg-black/40 backdrop-blur-md` for transparency effect
- **Back Button**: Added to Step 2 modal for navigation back to Step 1
- **Centered Text**: "LIMITED TIME ACCESS" text now centered under CTA buttons
- **Accessibility**: Added focus ring states on all interactive elements, reduced-motion support via `motion-reduce:` utilities and CSS media query
- **Theme Colors**: Consistent aquamarine (#14b8a6) accent throughout

### Files Modified
- `apps/landing/components/HeroSection.tsx` - Main hero and modal component
- `apps/landing/styles/hero.css` - Added reduced-motion CSS support

### Dashboard Slide (Dec 2024)
- **New Component**: `apps/landing/components/slides/DashboardSlide.tsx` - Full-page dashboard slide with neon heading, centered body text, and bullet points
- **New Route**: `/dashboard` page available at `apps/landing/app/dashboard/page.tsx`
- **CSS Additions**: Added `.neon-text`, `.neon-drop`, and `.bullet-dot` utilities to globals.css with reduced-motion support

### Components Slide / Slide 2 (Dec 2024)
- **New Component**: `apps/landing/components/Slides/ComponentsSlide.tsx` - Full-screen black slide with left-side vertical column of 8 clickable component buttons
- **New Route**: `/slide-2` page available at `apps/landing/app/slide-2/page.tsx`
- **Features**: Click any button for animated premium effect overlay with glow/ripple animations
- **Accessibility**: Full keyboard support (Tab, Enter, Space) with aria attributes
